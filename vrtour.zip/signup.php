	<?php 
	sleep(1);
		$MySql = new mysqli(
				"localhost", 
				"id6209379_vrtouruzb", 
				"vrtouruzb", 
				"id6209379_vrtouruzb"
				);

        $log = $_REQUEST["log"];;
		$pass = $_REQUEST["pass"];
		$type = $_REQUEST["type"];
		$name = $_REQUEST["name"];
		$mail = $_REQUEST["mail"];
		$tel = $_REQUEST["tel"];
		$tadname = $_REQUEST["tadname"];
		$loc = $_REQUEST["loc"];
		$tadtype = $_REQUEST["tadtype"];

		$date = date("Y-m-d");
        $res = $MySql->query("SELECT * FROM `users` WHERE log='$log'");
        if($res->num_rows == 0){   
    		$newuser = $MySql->query("INSERT INTO `users` 
    (id,view,name,mail,tel,type,tadname,tadtype,log,pass,date,country) VALUES 
    (null, 0, '$name', '$mail', '$tel', '$type', '$tadname', '$tadtype', '$log', '$pass', '$date', '$loc')");
	            $data = array("func"=>"true");   
        }else{
	            $data = array("func"=>"false");
        }
    
    echo (json_encode($data));
	?>
