	<?php 
	sleep(1);
		$MySql = new mysqli(
				"localhost", 
				"id6209379_vrtouruzb", 
				"vrtouruzb", 
				"id6209379_vrtouruzb"
				);

        $log = $_REQUEST["log"];
        $imgloc = $_REQUEST["imgloc"];
        
        $res = $MySql->query("UPDATE users SET image='$imgloc' WHERE tel='$log'");
    
    echo "succes";
	?>
