<?php
		$MySql = new mysqli(
				"localhost", 
				"id6209379_vrtouruzb", 
				"vrtouruzb", 
				"id6209379_vrtouruzb"
				);

		$date = date("Y-m-d");

		$newuser = $MySql->query("INSERT INTO `users` 
(id,view,name,mail,tel,type,tadname,tadtype,log,pass,date) VALUES 
(null, 0, '$_POST[name]', '$_POST[mail]', '$_POST[tel]', '$_POST[type]', '$_POST[tadname]', '$_POST[tadtype]', '$_POST[log]', '$_POST[pass]', '$date')");

		if( $newuser){
			echo "true";
		}else{
			echo "error";
		}
?>