	<?php 
	sleep(1);
		$MySql = new mysqli(
				"localhost", 
				"id6209379_vrtouruzb", 
				"vrtouruzb", 
				"id6209379_vrtouruzb"
				);

        $log = $_REQUEST["log"];
		$pass = $_REQUEST["pass"];

        $res = $MySql->query("SELECT * FROM `users` WHERE log='$log'");
        if($res->num_rows != 0){
	        $row = $res->fetch_assoc();
	        do{
	        	if( $pass == $row["pass"]){
	            	$data = array("func"=>"true","name"=>$row["name"],"tel"=>$row["tel"],"mail"=>$row["mail"],"tadname"=>$row["tadname"],"tadtype"=>$row["tadtype"],"type"=>$row["type"]);	        		
	        	}else{
	            	$data = array("func"=>"Parol yoki login xato kiritilgan."); 	        		
	        	}
	        }
	        while ($row = $res->fetch_assoc());
        }else{
	            $data = array("func"=>"Bunday telefon royxatga olinmagan.");        	
        }
    
    echo (json_encode($data));
	?>
