<?php 
		$MySql = new mysqli(
				"localhost", 
				"id6209379_vrtouruzb", 
				"vrtouruzb", 
				"id6209379_vrtouruzb"
				);

        $data = array();
	        $res = $MySql->query("SELECT * FROM `hisplases`");
	        if($res->num_rows != 0){
		        $row = $res->fetch_assoc();
		        $i=0;
		        do{
		        	$data["data_".$i] = json_encode($row);
		        	$i++;
		        }
		        while ($row = $res->fetch_assoc());
		        $data["num"] = $i;
	        }else{
	            $data["num"]=0;
	        }
		        echo json_encode($data);
?>